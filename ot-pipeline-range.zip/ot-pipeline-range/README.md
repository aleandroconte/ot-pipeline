# OT Pipeline Range — OT tampering reale (Modbus/TCP MITM)

Mini scenario Red vs Blue su **topologia reale**: 4 workstation di sito (Ubuntu 24)
che ricevono i valori dai rispettivi PLC e li inviano a **Centro**; una **Kali 24**
esegue un **MITM Modbus/TCP vero** sul link workstation→Centro e falsifica la portata,
nascondendo un furto fisico di cherosene.

```
  Ubuntu SITO (x4)                         Ubuntu CENTRAL            Kali ATTACCANTE
  ┌───────────────────────────┐            ┌─────────────┐         ┌───────────────┐
  │ PLC sim (Modbus :5020) ────┼─ loopback │ master      │         │ console WebUI │
  │   valori FISICI reali      │           │ Modbus      │         │ ① tap fisico  │
  │ workstation                │  Modbus   │ polla i 4   │         │ ② MITM reale  │
  │   GUI sito (solo la sua) ──┼───:502────▶ siti ───────▶ SCADA   │ ARP + proxy   │
  │   server Modbus :502 ──────┼────┐      │ centrale    │         └──────┬────────┘
  └───────────────────────────┘    │      └─────────────┘                │
                                    └──── intercettato dalla Kali ◀───────┘
                                         (ARP spoof + proxy che riscrive il reg. portata)
```

## Mappatura macchine ↔ GUI (ogni box alza SOLO la propria)

| Macchina | Ruolo | GUI alzata | Avvio |
|---|---|---|---|
| Ubuntu Pumping | site | HMI Pumping | `./run-pumping.sh` |
| Ubuntu Distribution | site | HMI Distribution | `./run-distribution.sh` |
| Ubuntu Military Airport 1 | site | HMI Military Airport 1 | `./run-militaryairport1.sh` |
| Ubuntu Military Airport 2 | site | HMI Military Airport 2 | `./run-militaryairport2.sh` |
| Ubuntu centralhmi | central | SCADA centrale | `./run-centralhmi.sh` |
| Kali 2026 | attacker | Console Red Team | `./run-attacker.sh` |

Ogni run-script di sito avvia il PLC simulato + la workstation e apre in kiosk **solo**
la GUI di quel sito (`site.html?site=<chiave>`), nient'altro.

## Come viaggiano i dati (tutto reale, niente sim centrale)
1. Il **PLC** di sito (`plc_sim.py`) è un server Modbus/TCP con i valori fisici reali.
2. La **workstation** (`app.py --role site`) polla il PLC locale, mostra la sua GUI
   con il valore **vero di campo**, e li ri-espone su un proprio server Modbus.
3. **Centro** (`app.py --role central`) è il master: polla le 4 workstation via Modbus.
   Questo è il link che la Kali manipola.
4. La **Kali** (`app.py --role attacker`) orchestra l'attacco e mostra il ground truth.

## L'attacco dalla Kali (reale, in due passi)
- **① Furto fisico** — la console imposta un *tap* sul PLC del terminale bersaglio
  (POST al canale scenario): la portata **reale** di campo cala. La GUI di sito,
  che legge il PLC, mostra il calo vero.
- **② Tampering MITM** — la console lancia `attacker/run_mitm.sh`:
  - `arp_spoof.py` (scapy) avvelena l'ARP di **Centro** e della **workstation**: il
    traffico Modbus passa per la Kali;
  - `iptables REDIRECT` dirotta il tcp/502 nel `mitm_proxy.py`, che riscrive il
    **registro 0 (portata)** nelle risposte verso Centro (+tap), preservando la
    lunghezza del frame. Centro torna a vedere il valore nominale → **nessun allarme**.

Risultato: **la workstation di sito mostra il valore vero, Centro vede quello falso.**
La divergenza tra i due è di per sé la prova (ottimo spunto per il Blue Team).

### Modi di inserimento (`MITM_MODE` in topology.conf)
- `arp` (default): ARP spoofing + REDIRECT trasparente — MITM reale on-wire.
- `route`: senza ARP; il proxy inoltra al sito e si punta Centro sull'attacker per quel
  sito. Fallback affidabile se lo switch blocca l'ARP spoofing.

### Modi di tampering (selezionabili dalla console)
- `offset`: aggiunge +spillamento alla sola **portata**. Semplice, ma livello e
  pressione restano reali: il cross-check inventario (portata piena + serbatoio che
  non sale) alla lunga smaschera il furto. Buono per *mostrare* il limite.
- `consistent`: portata = reale+spillamento **e** livello/pressione presi da una
  **baseline nominale** registrata prima del furto → la vista di Centro resta
  mutuamente coerente, batte anche il cross-check inventario.
- `replay`: **record-and-replay** in stile Stuxnet — tutta la telemetria verso Centro
  è una sequenza "sana" registrata prima del furto e rigiocata in loop. Massima furtività.

> Per `consistent` e `replay` il proxy ha bisogno di una finestra di **apprendimento**
> (default 8 s, `OTR_LEARN`): **avvia il MITM qualche secondo prima di aprire lo
> spillamento**, così la baseline registrata è nominale. In `offset` non serve.

## Installazione — stesso zip su tutte le macchine, uno script per macchina

L'idea: metti questo repo su GitHub, su **ogni** macchina scarichi lo **stesso** zip
(o `git clone`), poi lanci **un solo script**, diverso per macchina. Lo script, al
primo avvio, installa da sé tutto il necessario (apt + venv) e avvia il ruolo giusto.

```bash
# su OGNI macchina (una volta):
unzip ot-pipeline-range.zip && cd ot-pipeline-range      # oppure: git clone <repo> && cd ot-pipeline-range

# poi, SOLO lo script della macchina:
./run-pumping.sh      # sul box Pumping
./run-distribution.sh    # sul box Distribution
./run-militaryairport1.sh         # sul box Military Airport 1
./run-militaryairport2.sh        # sul box Military Airport 2
./run-centralhmi.sh         # sul box centralhmi
./run-attacker.sh          # sull'attacker
```

Stop su qualsiasi macchina: `./run-stop.sh` (ferma tutto e ripristina ARP/iptables).

Dietro **proxy** (macchine che escono su internet solo via proxy): esporta le variabili
prima di lanciare, apt e pip le rispettano:
```bash
export http_proxy=http://PROXY:PORT https_proxy=http://PROXY:PORT
./run-militaryairport1.sh
```

### Gli IP NON sono hardcoded
- I **box di sito** non hanno bisogno di conoscere alcun IP: `./run-militaryairport1.sh` funziona
  qualunque sia l'IP della macchina.
- **Centro** deve sapere gli IP dei 4 siti; **Kali** `CENTRAL_IP` e l'IP del sito bersaglio.
- Due modi per darli (l'ambiente ha la precedenza sul file):
  1. nel file `topology.conf` (si crea da solo dal `.example`: scommenta e metti gli IP), oppure
  2. al volo, davanti allo script:
     ```bash
     CENTRAL_IP=10.10.50.10 PUMPING_IP=10.10.10.11 DISTRIBUTION_IP=10.10.10.12 \
     MILITARYAIRPORT1_IP=10.10.10.13 MILITARYAIRPORT2_IP=10.10.10.14 ./run-centralhmi.sh

     CENTRAL_IP=10.10.50.10 MILITARYAIRPORT1_IP=10.10.10.13 ./run-attacker.sh
     ```
  Se mancano, Centro/Kali avvisano all'avvio quali IP configurare.

## Requisiti di rete
- Le 6 macchine sulla **stessa L2/VLAN** perché l'ARP spoofing funzioni.
- La porta **Modbus 502** richiede root: i run-script di sito e Kali usano `sudo`.
- Ambiente **isolato di laboratorio**: ARP spoofing e tampering Modbus solo qui dentro.

## Come è simulato il Modbus
Il PLC di ogni sito è un **server Modbus/TCP** realizzato con **pymodbus** (fissato a
`3.6.9`), con un loop di fisica che aggiorna gli holding register. Non si usa OpenPLC:
pymodbus tiene il tutto leggero, in puro Python, senza runtime/ladder logic da gestire.
Se in futuro vuoi logica di PLC reale (ladder, Modbus+DNP3, I/O), il PLC si può
sostituire con **OpenPLC** mantenendo invariati workstation, Centro e MITM: cambia solo
chi serve i register, non la mappa (vedi `common/sites.py`).

## Personalizzazione
- Siti/portate/colori: `common/sites.py` (backend) + `web/shared/sites.js` (frontend), allineati.
- Mappa registri Modbus: `common/sites.py` (`REG_*`).
- Soglia allarme ammanco (±2%): in `app.py`, ruolo central.

## Note di sicurezza
Scenario **didattico** per cyber range isolato: PLC, workstation e valori sono simulati;
nessun impianto reale è coinvolto. Tecniche — MITRE ATT&CK for ICS: **T0830**
Adversary-in-the-Middle, **T0832** Manipulation of View, **T0856** Spoof Reporting Message.
Usare esclusivamente sulla rete di laboratorio di cui si ha piena autorizzazione.
```
