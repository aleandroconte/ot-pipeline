#!/usr/bin/env bash
# Installazione dipendenze su Kali 24 (box ATTACCANTE). Aggiunge scapy.
# Idempotente: la richiama da sola ./run-kali.sh al primo avvio.
# Dietro proxy: esporta http_proxy/https_proxy prima di lanciare (apt usa sudo -E).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive

# NB: percorso ONLINE di riserva. Quello consigliato e' ./install_offline.sh attacker.
# iptables serve per il REDIRECT del MITM; niente chromium (snap): GUI nel browser presente.
echo "[setup] apt: python3-venv, python3-pip, iptables"
sudo -E apt-get update -y
sudo -E apt-get install -y python3-venv python3-pip iptables || true

echo "[setup] virtualenv + pip (incl. scapy)"
python3 -m venv "$ROOT/.venv"
"$ROOT/.venv/bin/pip" install --upgrade pip >/dev/null
"$ROOT/.venv/bin/pip" install -r "$ROOT/requirements-attacker.txt"

chmod +x "$ROOT"/run-*.sh "$ROOT"/scripts/*.sh "$ROOT"/attacker/*.sh "$ROOT"/attacker/*.py 2>/dev/null || true
[[ -f "$ROOT/topology.conf" ]] || cp "$ROOT/topology.conf.example" "$ROOT/topology.conf"
echo "[setup] completato."
