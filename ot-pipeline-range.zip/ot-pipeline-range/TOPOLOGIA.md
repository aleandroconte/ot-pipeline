# Topologia del teatro (cyber range) e router VyOS 1.5

Come costruire la rete del demo: **due subnet** collegate da un **router VyOS 1.5 LTS**,
con l'attacker insieme ai siti e la centralhmi isolata.

## 1. Schema

```
              Subnet CENTER 10.10.50.0/24
              ┌───────────────────────────┐
              │   centralhmi  .10          │
              │        │                   │
              │   [ switch: center ]       │
              └────────┬──────────────────-┘
                       │ eth1  10.10.50.150
                 ┌─────┴─────┐
                 │  router   │  (VyOS 1.5, L3)
                 └─────┬─────┘
                       │ eth0  10.10.10.150
              ┌────────┴───────────────────┐
              │   [ switch: field ]        │
              │   │    │    │    │    │     │
              │  pump dist mil1 mil2 attacker
              │  .11  .12  .13  .14  .66    │
              │   Subnet FIELD 10.10.10.0/24│
              └────────────────────────────┘
```

Perché così: l'attacco MITM usa **ARP spoofing**, che è di livello 2 e funziona **solo
dentro la stessa subnet**. L'attacker deve quindi stare nella subnet dei siti; per
intercettare il traffico diretto alla centralhmi (che è oltre il router) avvelena l'ARP
tra il **sito bersaglio** e il **gateway field** (`10.10.10.150`).

## 2. Composizione nel Cyber Range
Il teatro ha il minimo di **2 subnet**. Crea:
- **Subnet "field"** `10.10.10.0/24` — switch `field` — collega: pumping, distribution,
  militaryairport1, militaryairport2, attacker.
- **Subnet "center"** `10.10.50.0/24` — switch `center` — collega: centralhmi.
- **1 nodo router VyOS 1.5** (hostname `router`) con **2 schede**, una per subnet.
  Ogni host ha come **default gateway** il `.150` della propria subnet.

## 3. Piano IP

| Nodo | SO | Subnet | IP | Gateway |
|---|---|---|---|---|
| centralhmi | Ubuntu 24.04 | center 10.10.50.0/24 | 10.10.50.10 | 10.10.50.150 |
| pumping | Ubuntu 24.04 | field 10.10.10.0/24 | 10.10.10.11 | 10.10.10.150 |
| distribution | Ubuntu 24.04 | field | 10.10.10.12 | 10.10.10.150 |
| militaryairport1 | Ubuntu 24.04 | field | 10.10.10.13 | 10.10.10.150 |
| militaryairport2 | Ubuntu 24.04 | field | 10.10.10.14 | 10.10.10.150 |
| attacker | Kali 2026 | field | 10.10.10.66 | 10.10.10.150 |
| router eth0 | VyOS 1.5 | field | 10.10.10.150 | — |
| router eth1 | VyOS 1.5 | center | 10.10.50.150 | — |

Puoi cambiare gli IP: aggiorna in parallelo `topology.conf` (su centralhmi/attacker) e la
config del router.

## 4. Configurare il router VyOS 1.5
Due modi, stesso risultato.

**A) Script (consigliato).** Copia `router/configure_vyos.sh` sul router (es. in
`/config/scripts/`) e lancialo:
```bash
bash /config/scripts/configure_vyos.sh
```

**B) A mano.** In `configure`, incolla i comandi di `router/vyos-router-1.5.conf`, poi
`commit ; save ; exit`.

> **Verifica la mappatura NIC**: lo script assume `eth0 = field`, `eth1 = center`. Nel tuo
> teatro l'ordine può cambiare: controlla con `show interfaces` e, se serve, scambia gli
> indirizzi. L'instradamento tra le due subnet direttamente connesse è **automatico**: non
> servono rotte statiche.

**Firewall**: lo script usa di default il profilo **lab permissivo** (instrada tutto tra
le subnet). In `vyos-router-1.5.conf` trovi, commentata, la variante **ristretta** (solo
`502` centralhmi→siti, `8080` attacker→centralhmi, icmp, stateful) per la versione Blue.

**Internet al primo avvio**: gli host scaricano i pacchetti solo al **primo** `./run-*.sh`.
Se il teatro fornisce già internet/proxy, il router non serve per questo. Altrimenti
scommenta nello script la sezione **WAN/NAT** (eth2 in DHCP + masquerade).

## 5. Flussi che devono attraversare il router
| Da | A | Porta | Perché |
|---|---|---|---|
| centralhmi 10.10.50.10 | siti 10.10.10.0/24 | TCP 502 | polling Modbus dei siti |
| siti | centralhmi | (established) | risposte Modbus |
| attacker 10.10.10.66 | centralhmi 10.10.50.10 | TCP 8080 | la console legge /api/state |
| qualsiasi | qualsiasi | ICMP | ping di collaudo |

## 6. Checklist di collaudo (prima della demo)
```bash
# 1) il router vede entrambe le reti
show interfaces                     # eth0=.150 field, eth1=.150 center, UP

# 2) instradamento tra subnet (da un sito)
ping 10.10.50.10                    # centralhmi risponde attraverso il router

# 3) dalla centralhmi verso un sito
ping 10.10.10.13

# 4) Modbus raggiungibile (dalla centralhmi)
nc -vz 10.10.10.13 502

# 5) l'attacker vede l'oracolo locale e la centralhmi
curl -s http://10.10.10.13:8091/state
curl -s http://10.10.50.10:8080/api/state | head -c 120

# 6) interfaccia giusta sull'attacker per l'ARP
ip -br a                            # annota il nome NIC -> OTR_IFACE
```
Se tutto risponde: avvia i ruoli (`./run-*.sh`) nell'ordine **siti → centralhmi →
attacker** e segui `DEMO_SCRIPT.md` / `PLAYBOOK_MANUALE.md`.

## 7. Promemoria attacco a 2 subnet
Sull'attacker, in `topology.conf`: `OTR_UPSTREAM=10.10.10.150` (gateway field). Lo spoofing
va tra sito e gateway, non verso la centralhmi:
```bash
sudo bash attacker/run_mitm.sh start 10.10.50.10 10.10.10.13 60 offset
#   (CENTRAL_IP serve solo a identificare la dest reale lato proxy; l'ARP usa OTR_UPSTREAM)
```
