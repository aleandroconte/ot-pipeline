"""Parametri dei siti e mappa registri Modbus (unica fonte di verita').
Rispecchia web/shared/sites.js lato frontend.
"""

# Parametri nominali per sito
SITES = {
    "pumping":  {"name": "Pumping",  "subtitle": "Stazione di pompaggio",     "role": "sorgente",  "accent": "#2e86de", "flow": 800.0, "pressure": 52.0, "tanks": 4, "level": 78.0, "pumps": 3},
    "distribution":{"name": "Distribution", "subtitle": "Nodo di distribuzione",     "role": "nodo",      "accent": "#e1a33a", "flow": 800.0, "pressure": 46.0, "tanks": 2, "level": 61.0, "pumps": 2},
    "militaryairport1":     {"name": "Military Airport 1",      "subtitle": "Terminale aeroportuale", "role": "terminale", "accent": "#8e44ad", "flow": 450.0, "pressure": 38.0, "tanks": 3, "level": 54.0, "pumps": 1},
    "militaryairport2":    {"name": "Military Airport 2",     "subtitle": "Terminale aeroportuale", "role": "terminale", "accent": "#27a567", "flow": 350.0, "pressure": 36.0, "tanks": 3, "level": 49.0, "pumps": 1},
}
ORDER = ["pumping", "distribution", "militaryairport1", "militaryairport2"]
# Terminali di ricezione: punti dove l'attaccante puo' aprire lo spillamento
THEFT_TARGETS = ["militaryairport1", "militaryairport2"]

# --- mappa registri (holding registers) ---------------------------------
#  I valori analogici sono memorizzati come interi x10 (1 decimale).
REG_FLOW = 0      # portata   m3/h x10
REG_PRESS = 1     # pressione bar  x10
REG_LEVEL = 2     # livello   %    x10
REG_TEMP = 3      # temperatura C  x10
REG_PUMP = 4      # pompe attive   (conteggio)
REG_COUNT = 5     # numero di registri letti in un colpo da Centro

SCALE = 10.0      # fattore di scala per i valori analogici


def enc(flow, press, level, temp, pump):
    """Valori ingegneristici -> lista registri Modbus."""
    return [
        int(round(flow * SCALE)),
        int(round(press * SCALE)),
        int(round(level * SCALE)),
        int(round(temp * SCALE)),
        int(round(pump)),
    ]


def dec(regs):
    """Lista registri Modbus -> dict ingegneristico."""
    return {
        "flow": regs[REG_FLOW] / SCALE,
        "pressure": regs[REG_PRESS] / SCALE,
        "tank_level": regs[REG_LEVEL] / SCALE,
        "temp": regs[REG_TEMP] / SCALE,
        "pump_on": int(regs[REG_PUMP]),
    }
