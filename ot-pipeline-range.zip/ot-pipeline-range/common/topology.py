"""Lettura di topology.conf (file KEY=VALUE, condiviso con bash)."""
import os

DEFAULTS = {
    "CENTRAL_IP": "127.0.0.1",
    "PUMPING_IP": "127.0.0.1",
    "DISTRIBUTION_IP": "127.0.0.1",
    "MILITARYAIRPORT1_IP": "127.0.0.1",
    "MILITARYAIRPORT2_IP": "127.0.0.1",
    "ATTACKER_IP": "127.0.0.1",
    "MODBUS_PORT": "502",     # workstation di sito -> espone a Centro
    "PLC_PORT": "5020",       # PLC locale sul box di sito (loopback)
    "WEB_PORT": "8080",       # GUI web del ruolo
    "SCENARIO_PORT": "8091",  # canale iniezione scenario sul PLC
    "POLL_MS": "1000",        # periodo polling Modbus
}


def load(path=None):
    cfg = dict(DEFAULTS)
    path = path or os.environ.get("OTR_TOPOLOGY") or _find()
    if path and os.path.exists(path):
        for line in open(path):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.split("#", 1)[0].strip().strip('"').strip("'")
    # override da ambiente
    for k in list(cfg):
        if k in os.environ:
            cfg[k] = os.environ[k]
    return cfg


def _find():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for name in ("topology.conf", "topology.conf.example"):
        p = os.path.join(here, name)
        if os.path.exists(p):
            return p
    return None


def site_ip(cfg, site):
    return cfg.get(site.upper() + "_IP", "127.0.0.1")
