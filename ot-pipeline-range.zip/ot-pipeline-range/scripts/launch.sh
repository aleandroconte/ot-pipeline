#!/usr/bin/env bash
# =====================================================================
#  Dispatcher unico: installa (al primo avvio) e lancia il ruolo richiesto.
#  Non si usa di norma a mano: lo chiamano i lanciatori ./run-<macchina>.sh
#     scripts/launch.sh site <sito>
#     scripts/launch.sh central
#     scripts/launch.sh attacker
#
#  IP: NON sono hardcoded. Vengono letti da topology.conf oppure da variabili
#  d'ambiente passate al volo (l'ambiente ha la precedenza). Vedi README.
#  I box di SITO non hanno bisogno di alcun IP. Solo Centro e Kali.
# =====================================================================
set -uo pipefail
ROLE="${1:?ruolo mancante}"; SITE="${2:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

CONF="$ROOT/topology.conf"
[[ -f "$CONF" ]] || cp "$ROOT/topology.conf.example" "$CONF"
export OTR_TOPOLOGY="$CONF"

# porta web per aprire il browser (letta senza 'source', per non sovrascrivere l'ambiente)
WEB_PORT="$(sed -n 's/^[[:space:]]*WEB_PORT[[:space:]]*=[[:space:]]*\([0-9]\+\).*/\1/p' "$CONF" | head -1)"
WEB_PORT="${WEB_PORT:-8080}"

# ---- installazione idempotente (prima esecuzione) ----
if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  echo "[setup] prima esecuzione su questa macchina: installo le dipendenze..."
  if [[ "$ROLE" == "attacker" ]]; then
    bash "$ROOT/install_kali.sh"
  else
    bash "$ROOT/install_ubuntu.sh"
  fi
fi
PY="$ROOT/.venv/bin/python"
[[ -x "$PY" ]] || PY=python3
mkdir -p "$ROOT/.run"

open_gui() {
  local url="http://localhost:${WEB_PORT}/"
  echo "[$ROLE${SITE:+:$SITE}] GUI: $url"
  [[ -z "${DISPLAY:-}" ]] && { echo "    (nessun display: apri $url in un browser)"; return; }
  for b in chromium chromium-browser google-chrome firefox; do
    if command -v "$b" >/dev/null 2>&1; then
      if [[ "$b" == firefox ]]; then ("$b" --new-window "$url" >/dev/null 2>&1 &)
      else ("$b" --new-window --app="$url" --user-data-dir="/tmp/otr-$ROLE$SITE" >/dev/null 2>&1 &); fi
      return
    fi
  done
  echo "    (nessun browser: apri $url)"
}

warn_ips() {  # avvisa se gli IP non sono stati configurati su Centro/Kali
  local miss=0
  for v in "$@"; do
    local val="${!v:-}"
    [[ -z "$val" ]] && val="$(sed -n "s/^[[:space:]]*$v[[:space:]]*=[[:space:]]*//p" "$CONF" | head -1)"
    [[ -z "$val" || "$val" == 127.0.0.1 ]] && { echo "    [!] $v non configurato (ora: ${val:-vuoto})"; miss=1; }
  done
  if [[ $miss == 1 ]]; then
    echo "    Configura gli IP in topology.conf, oppure passali al volo, es.:"
    echo "      CENTRAL_IP=10.0.0.50 MILITARYAIRPORT1_IP=10.0.0.33 ./run-centralhmi.sh"
  fi
}

case "$ROLE" in
  site)
    [[ -n "$SITE" ]] || { echo "manca il nome del sito"; exit 1; }
    echo "[site:$SITE] questa macchina non ha bisogno di conoscere alcun IP."
    sudo -E env OTR_TOPOLOGY="$CONF" "$PY" plc_sim.py --site "$SITE" >"$ROOT/.run/plc-$SITE.log" 2>&1 &
    echo $! >"$ROOT/.run/plc-$SITE.pid"; sleep 2
    sudo -E env OTR_TOPOLOGY="$CONF" "$PY" app.py --role site --site "$SITE" >"$ROOT/.run/ws-$SITE.log" 2>&1 &
    echo $! >"$ROOT/.run/ws-$SITE.pid"; sleep 2
    open_gui ;;
  central)
    echo "[central] raggiungo le 4 workstation di sito via Modbus."
    warn_ips PUMPING_IP DISTRIBUTION_IP MILITARYAIRPORT1_IP MILITARYAIRPORT2_IP
    "$PY" app.py --role central >"$ROOT/.run/central.log" 2>&1 &
    echo $! >"$ROOT/.run/central.pid"; sleep 2
    open_gui ;;
  attacker)
    echo "[attacker] console Red Team (MITM richiede root → sudo)."
    warn_ips CENTRAL_IP MILITARYAIRPORT1_IP MILITARYAIRPORT2_IP
    sudo -E env OTR_TOPOLOGY="$CONF" "$PY" app.py --role attacker >"$ROOT/.run/attacker.log" 2>&1 &
    echo $! >"$ROOT/.run/attacker.pid"; sleep 2
    open_gui ;;
  *) echo "ruolo sconosciuto: $ROLE"; exit 1 ;;
esac

echo "[$ROLE${SITE:+:$SITE}] attivo. Stop:  ./run-stop.sh"
