#!/usr/bin/env bash
# Ferma tutti i processi OTR avviati su questa macchina.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# ferma eventuale MITM (ripristina ARP/iptables)
[[ -f "$ROOT/attacker/run_mitm.sh" ]] && sudo bash "$ROOT/attacker/run_mitm.sh" stop 2>/dev/null || true
if [[ -d "$ROOT/.run" ]]; then
  for pf in "$ROOT"/.run/*.pid; do
    [[ -e "$pf" ]] || continue
    pid="$(cat "$pf")"
    sudo kill "$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
    rm -f "$pf"
  done
fi
pkill -f "user-data-dir=/tmp/otr-" 2>/dev/null || true
echo "OTR fermato su questa macchina."
