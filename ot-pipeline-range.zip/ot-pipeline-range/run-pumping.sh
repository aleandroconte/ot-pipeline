#!/usr/bin/env bash
# Lanciatore per pumping — installa (al primo avvio) e avvia il ruolo.
exec "$(cd "$(dirname "$0")" && pwd)/scripts/launch.sh" site pumping
