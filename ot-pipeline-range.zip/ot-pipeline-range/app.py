#!/usr/bin/env python3
"""
App a ruoli del cyber range OTR. Un solo file, tre ruoli.

  --role site --site <key>   (su ogni Ubuntu di sito)
      * fa da client Modbus verso il PLC locale (loopback:PLC_PORT)
      * rispecchia i valori in un PROPRIO server Modbus (MODBUS_PORT) che Centro legge
      * serve SOLO la GUI HMI di quel sito + WS con i suoi valori (VERI, dal PLC)

  --role central               (sulla Ubuntu di Centro)
      * fa da master Modbus: interroga le 4 workstation (<site_ip>:MODBUS_PORT)
      * questo e' il link che la Kali puo' manipolare -> i valori possono essere falsificati
      * serve la GUI SCADA centrale + WS + /api/state

  --role attacker            (sulla Kali)
      * serve la console Red Team + WS
      * ground truth: legge i PLC via oracolo HTTP (<site_ip>:SCENARIO_PORT/state)
      * vista Centro: legge Centro /api/state
      * controlla l'attacco: tap fisico (POST al PLC) e MITM reale (run_mitm.sh)
"""
import argparse
import asyncio
import json
import os
import subprocess
import threading
import time
import urllib.request

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from pymodbus.client import ModbusTcpClient
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
from pymodbus.server import StartTcpServer

from common import sites as S
from common import topology as T

HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")

PUB = {}            # stato pubblicato via WS (shape dipende dal ruolo)
ATTACK = {"target": "militaryairport1", "tap": 60.0, "tap_active": False,
          "mitm_active": False, "mode": "offset"}


def http_json(url, timeout=1.0, method="GET"):
    req = urllib.request.Request(url, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


# =====================================================================
#  RUOLO SITE
# =====================================================================
def role_site(app, cfg, site):
    plc_port = int(cfg["PLC_PORT"])
    ws_port = int(cfg["MODBUS_PORT"])
    poll = int(cfg["POLL_MS"]) / 1000.0

    # server Modbus che Centro legge (rispecchia il PLC)
    store = ModbusSlaveContext(hr=ModbusSequentialDataBlock(0, [0] * 20))
    ctx = ModbusServerContext(slaves=store, single=True)
    threading.Thread(target=lambda: StartTcpServer(context=ctx, address=("0.0.0.0", ws_port)),
                     daemon=True).start()

    def poll_loop():
        cli = ModbusTcpClient("127.0.0.1", port=plc_port)
        while True:
            try:
                if not cli.connected:
                    cli.connect()
                rr = cli.read_holding_registers(0, count=S.REG_COUNT, slave=1)
                if not rr.isError():
                    regs = rr.registers
                    store.setValues(3, 0, regs)         # espone a Centro
                    d = S.dec(regs)
                    PUB["site"] = {"key": site, "alarm": False, **d}
            except Exception:
                try:
                    cli.close()
                except Exception:
                    pass
            time.sleep(poll)
    threading.Thread(target=poll_loop, daemon=True).start()

    @app.get("/")
    async def root():
        return RedirectResponse(f"/web/site.html?site={site}&lock=1")

    def payload():
        return {"site": PUB.get("site", {"key": site, "alarm": False})}
    app.state.payload = payload


# =====================================================================
#  RUOLO CENTRAL
# =====================================================================
def role_central(app, cfg):
    ws_port = int(cfg["MODBUS_PORT"])
    poll = int(cfg["POLL_MS"]) / 1000.0
    ips = {k: T.site_ip(cfg, k) for k in S.ORDER}

    def poll_loop():
        clients = {k: ModbusTcpClient(ips[k], port=ws_port) for k in S.ORDER}
        ema = [None]   # media mobile dello sbilanciamento (anti-falsi positivi da rumore)
        while True:
            rep = {}
            for k in S.ORDER:
                cli = clients[k]
                try:
                    if not cli.connected:
                        cli.connect()
                    rr = cli.read_holding_registers(0, count=S.REG_COUNT, slave=1)
                    if not rr.isError():
                        rep[k] = {"key": k, "alarm": False, **S.dec(rr.registers)}
                    else:
                        rep[k] = PUB.get("reported", {}).get(k, {"key": k, "flow": 0, "pressure": 0, "tank_level": 0, "temp": 0, "pump_on": 0, "alarm": True})
                except Exception:
                    try:
                        cli.close()
                    except Exception:
                        pass
                    rep[k] = PUB.get("reported", {}).get(k, {"key": k, "flow": 0, "pressure": 0, "tank_level": 0, "temp": 0, "pump_on": 0, "alarm": True})
            # bilancio di massa sui dati ricevuti (post eventuale MITM)
            mand = rep["pumping"]["flow"]
            ric = rep["militaryairport1"]["flow"] + rep["militaryairport2"]["flow"]
            imb = mand - ric
            # media mobile: smorza il rumore istantaneo, evita falsi allarmi
            ema[0] = imb if ema[0] is None else (0.3 * imb + 0.7 * ema[0])
            imb_s = ema[0]
            imbp = (imb_s / mand * 100.0) if mand else 0.0
            alarm = abs(imbp) > 2.0
            if alarm:
                rep["militaryairport1"]["alarm"] = True
                rep["militaryairport2"]["alarm"] = True
            PUB["reported"] = rep
            PUB["balance"] = {"mand_ls": round(mand, 1), "ric_tot": round(ric, 1),
                              "imbalance": round(imb_s, 1), "imbalance_pct": round(imbp, 2),
                              "alarm": alarm}
            time.sleep(poll)
    threading.Thread(target=poll_loop, daemon=True).start()

    @app.get("/")
    async def root():
        return RedirectResponse("/web/central.html")

    @app.get("/api/state")
    async def api_state():
        return {"reported": PUB.get("reported", {}), "balance": PUB.get("balance", {})}

    def payload():
        return {"reported": PUB.get("reported", {}), "balance": PUB.get("balance", {})}
    app.state.payload = payload


# =====================================================================
#  RUOLO ATTACKER (Kali)
# =====================================================================
def role_attacker(app, cfg):
    poll = 0.5
    central_ip = cfg["CENTRAL_IP"]
    central_web = int(cfg["WEB_PORT"])
    scen_port = int(cfg["SCENARIO_PORT"])
    mitm_proc = {"p": None}

    def nominal(k):
        return S.SITES[k]["flow"]

    def oracle_loop():
        while True:
            real = {}
            for k in S.ORDER:
                try:
                    d = http_json(f"http://{T.site_ip(cfg, k)}:{scen_port}/state")
                    real[k] = {"key": k, "flow": d["flow"], "pressure": d["pressure"],
                               "tank_level": d["tank_level"], "temp": d["temp"],
                               "pump_on": d["pump_on"], "tap": d.get("tap", 0), "alarm": False}
                except Exception:
                    real[k] = real.get(k, {"key": k, "flow": 0, "pressure": 0, "tank_level": 0, "temp": 0, "pump_on": 0, "tap": 0, "alarm": False})
            # vista Centro (cio' che Centro vede, post-MITM)
            try:
                ps = http_json(f"http://{central_ip}:{central_web}/api/state")
                reported = ps.get("reported", {})
                balance = ps.get("balance", {})
            except Exception:
                reported, balance = {}, {}
            PUB["real"] = real
            PUB["reported"] = reported
            PUB["balance"] = balance
            PUB["attack"] = dict(ATTACK)
            time.sleep(poll)
    threading.Thread(target=oracle_loop, daemon=True).start()

    @app.get("/")
    async def root():
        return RedirectResponse("/web/attacker.html")

    @app.post("/api/attack/tap")
    async def set_tap(req: Request):
        b = await req.json()
        ATTACK["target"] = b.get("target", ATTACK["target"])
        ATTACK["tap"] = float(b.get("tap", ATTACK["tap"]))
        ATTACK["tap_active"] = bool(b.get("active", ATTACK["tap_active"]))
        rate = ATTACK["tap"] if ATTACK["tap_active"] else 0.0
        ip = T.site_ip(cfg, ATTACK["target"])
        try:
            http_json(f"http://{ip}:{scen_port}/scenario?tap={rate}", method="POST")
            ok = True
        except Exception as e:
            ok = False
        # se il MITM e' attivo, riallinea il delta al nuovo tap
        if ATTACK["mitm_active"]:
            _start_mitm()
        return {"ok": ok, **ATTACK}

    def _start_mitm():
        _stop_mitm()
        site = ATTACK["target"]
        delta = ATTACK["tap"] if ATTACK["tap_active"] else ATTACK["tap"]
        script = os.path.join(HERE, "attacker", "run_mitm.sh")
        env = dict(os.environ)
        env.update(OTR_TOPOLOGY=os.environ.get("OTR_TOPOLOGY", T._find() or ""))
        try:
            mitm_proc["p"] = subprocess.Popen(
                ["bash", script, "start", central_ip, T.site_ip(cfg, site),
                 str(delta), ATTACK.get("mode", "offset")],
                env=env)
            ATTACK["mitm_active"] = True
        except Exception:
            ATTACK["mitm_active"] = False

    def _stop_mitm():
        script = os.path.join(HERE, "attacker", "run_mitm.sh")
        try:
            subprocess.run(["bash", script, "stop"], timeout=10)
        except Exception:
            pass
        p = mitm_proc.get("p")
        if p and p.poll() is None:
            try:
                p.terminate()
            except Exception:
                pass
        mitm_proc["p"] = None

    @app.post("/api/attack/mitm")
    async def set_mitm(req: Request):
        b = await req.json()
        if b.get("mode") in ("offset", "consistent", "replay"):
            ATTACK["mode"] = b["mode"]
        if b.get("active"):
            ATTACK["target"] = b.get("target", ATTACK["target"])
            _start_mitm()
        else:
            _stop_mitm()
            ATTACK["mitm_active"] = False
        return {"ok": True, **ATTACK}

    def payload():
        return {"real": PUB.get("real", {}), "reported": PUB.get("reported", {}),
                "balance": PUB.get("balance", {}), "attack": dict(ATTACK)}
    app.state.payload = payload


# =====================================================================
#  BOOTSTRAP
# =====================================================================
def build():
    ap = argparse.ArgumentParser()
    ap.add_argument("--role", required=True, choices=["site", "central", "attacker"])
    ap.add_argument("--site", choices=S.ORDER)
    ap.add_argument("--config")
    args, _ = ap.parse_known_args()
    cfg = T.load(args.config)
    if args.config:
        os.environ["OTR_TOPOLOGY"] = args.config

    app = FastAPI(title=f"OTR {args.role}")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    if args.role == "site":
        assert args.site, "--site richiesto per role=site"
        role_site(app, cfg, args.site)
    elif args.role == "central":
        role_central(app, cfg)
    else:
        role_attacker(app, cfg)

    @app.websocket("/ws")
    async def ws(sock: WebSocket):
        await sock.accept()
        try:
            while True:
                await sock.send_text(json.dumps(app.state.payload()))
                await asyncio.sleep(0.5)
        except WebSocketDisconnect:
            pass
        except Exception:
            pass

    app.mount("/web", StaticFiles(directory=WEB, html=True), name="web")
    return app, cfg, args


app, _CFG, _ARGS = build()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(_CFG["WEB_PORT"]))
