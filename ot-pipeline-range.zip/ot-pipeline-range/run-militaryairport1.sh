#!/usr/bin/env bash
# Lanciatore per militaryairport1 — installa (al primo avvio) e avvia il ruolo.
exec "$(cd "$(dirname "$0")" && pwd)/scripts/launch.sh" site militaryairport1
