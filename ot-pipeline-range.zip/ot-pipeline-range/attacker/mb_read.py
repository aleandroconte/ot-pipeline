#!/usr/bin/env python3
"""
Lettore Modbus/TCP di ricognizione (Red Team) — legge gli holding register di un
bersaglio e li decodifica nei valori di processo. Utile in demo per mostrare il
valore REALE sul filo, prima/dopo il tampering.

Uso:
  .venv/bin/python attacker/mb_read.py <host> [porta=502] [count=5] [slave=1]
Esempi:
  .venv/bin/python attacker/mb_read.py 10.0.0.13          # workstation Military Airport 1 (reale)
  .venv/bin/python attacker/mb_read.py 10.0.0.13 502
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pymodbus.client import ModbusTcpClient
try:
    from common import sites as S
    decode = S.dec
except Exception:
    decode = None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    host = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 502
    count = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    slave = int(sys.argv[4]) if len(sys.argv) > 4 else 1

    c = ModbusTcpClient(host, port=port)
    if not c.connect():
        print(f"[!] connessione fallita a {host}:{port}")
        sys.exit(2)
    print(f"[mb_read] {host}:{port}  (slave {slave}) — Ctrl-C per uscire\n")
    try:
        while True:
            rr = c.read_holding_registers(0, count=count, slave=slave)
            if rr.isError():
                print("  errore di lettura:", rr)
            else:
                regs = rr.registers
                if decode and count >= 5:
                    d = decode(regs)
                    print(f"  portata={d['flow']:7.1f} m3/h | pressione={d['pressure']:5.1f} bar | "
                          f"livello={d['tank_level']:5.1f} % | temp={d['temp']:4.1f} C | pompe={d['pump_on']}")
                else:
                    print("  registri:", regs)
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        c.close()


if __name__ == "__main__":
    main()
