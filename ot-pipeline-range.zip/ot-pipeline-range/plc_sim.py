#!/usr/bin/env python3
"""
PLC simulato (uno per sito) — server Modbus/TCP con i valori FISICI REALI.

- Espone holding register 0..4 (vedi common/sites.py) = portata, pressione,
  livello, temperatura, pompe. Li legge la workstation locale del sito.
- Esegue la fisica: oscillazioni realistiche attorno ai nominali.
- "Furto fisico": un canale di scenario HTTP imposta un tap_rate (m3/h)
  che viene sottratto alla portata reale (rappresenta la valvola clandestina).
- Lo stesso canale HTTP espone GET /state = verita' di campo (oracolo usato
  dalla console Red Team per il confronto reale-vs-Centro).

Uso:  python3 plc_sim.py --site militaryairport1
"""
import argparse
import json
import math
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
from pymodbus.server import StartTcpServer

from common import sites as S
from common import topology as T

state = {"flow": 0, "pressure": 0, "tank_level": 0, "temp": 19.0, "pump_on": 0, "tap": 0.0}
_lock = threading.Lock()


def physics_loop(site, store):
    c = S.SITES[site]
    t0 = time.time()
    level = c["level"]
    while True:
        t = time.time() - t0
        base = c["flow"]
        wobble = math.sin(t * 0.25 + len(site)) * base * 0.004
        noise = random.uniform(-1, 1) * base * 0.0015
        with _lock:
            tap = state["tap"]
        flow = max(0.0, base + wobble + noise - tap)
        press = c["pressure"] + math.sin(t * 0.3) * 0.4 + random.uniform(-0.15, 0.15)
        temp = 19.0 + math.sin(t * 0.05) * 1.5 + random.uniform(-0.1, 0.1)
        # livello: se c'e' furto a un terminale, il serbatoio sale piu' piano
        level -= (tap / 6000.0)
        level = max(0.0, min(100.0, level + random.uniform(-0.02, 0.03)))
        regs = S.enc(flow, press, level, temp, c["pumps"])
        store.setValues(3, 0, regs)  # fc3 = holding registers, da addr 0
        with _lock:
            state.update(flow=round(flow, 1), pressure=round(press, 2),
                         tank_level=round(level, 1), temp=round(temp, 1),
                         pump_on=c["pumps"])
        time.sleep(0.5)


def make_http(site):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silenzioso
            pass

        def _send(self, obj, code=200):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            p = urlparse(self.path)
            if p.path == "/state":
                with _lock:
                    self._send({"site": site, **state})
            elif p.path == "/scenario":
                with _lock:
                    self._send({"site": site, "tap": state["tap"]})
            else:
                self._send({"error": "not found"}, 404)

        def do_POST(self):
            p = urlparse(self.path)
            if p.path == "/scenario":
                q = parse_qs(p.query)
                if "tap" in q:
                    try:
                        val = max(0.0, min(300.0, float(q["tap"][0])))
                        with _lock:
                            state["tap"] = val
                        self._send({"site": site, "tap": val})
                        return
                    except ValueError:
                        pass
                self._send({"error": "param tap mancante/invalido"}, 400)
            else:
                self._send({"error": "not found"}, 404)
    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", required=True, choices=S.ORDER)
    ap.add_argument("--config")
    args = ap.parse_args()
    cfg = T.load(args.config)
    plc_port = int(cfg["PLC_PORT"])
    scen_port = int(cfg["SCENARIO_PORT"])

    store = ModbusSlaveContext(hr=ModbusSequentialDataBlock(0, [0] * 20))
    ctx = ModbusServerContext(slaves=store, single=True)

    threading.Thread(target=physics_loop, args=(args.site, store), daemon=True).start()
    httpd = ThreadingHTTPServer(("0.0.0.0", scen_port), make_http(args.site))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()

    print(f"[PLC {args.site}] Modbus su :{plc_port} | scenario/oracolo HTTP su :{scen_port}")
    StartTcpServer(context=ctx, address=("0.0.0.0", plc_port))


if __name__ == "__main__":
    main()
