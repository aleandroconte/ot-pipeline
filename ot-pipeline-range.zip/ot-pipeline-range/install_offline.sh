#!/usr/bin/env bash
# =====================================================================
#  Installazione OFFLINE delle dipendenze Python.
#  Usa SOLO le wheel in vendor/wheels: niente rete, niente proxy, niente
#  apt, niente snap. Richiede solo python3 (gia' presente su Ubuntu 24).
#
#  Crea vendor/libs/ con tutte le librerie; i launcher la usano via
#  PYTHONPATH. Idempotente: la richiama da sola scripts/launch.sh.
#
#  Uso:
#     ./install_offline.sh            # ruoli di sito / centralhmi
#     ./install_offline.sh attacker   # aggiunge scapy (box Kali)
# =====================================================================
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WH="$ROOT/vendor/wheels"
LIBS="$ROOT/vendor/libs"
REQ="$ROOT/requirements.txt"
[[ "${1:-}" == "attacker" ]] && REQ="$ROOT/requirements-attacker.txt"

[[ -d "$WH" ]] || { echo "[offline] ERRORE: manca $WH (bundle incompleto)"; exit 1; }
PIPWHL="$(ls "$WH"/pip-*.whl 2>/dev/null | head -1)"
[[ -n "$PIPWHL" ]] || { echo "[offline] ERRORE: manca la wheel di pip in $WH"; exit 1; }

command -v python3 >/dev/null 2>&1 || { echo "[offline] ERRORE: python3 non trovato"; exit 1; }
echo "[offline] python: $(python3 --version 2>&1)"

run_pip() {  # esegue pip SENZA che sia installato nel sistema
  if python3 "$PIPWHL/pip" --version >/dev/null 2>&1; then
    python3 "$PIPWHL/pip" "$@"
  else
    PYTHONPATH="$PIPWHL" python3 -m pip "$@"
  fi
}

echo "[offline] installo le dipendenze da vendor/wheels -> vendor/libs ..."
rm -rf "$LIBS"; mkdir -p "$LIBS"
if ! run_pip install --no-index --find-links "$WH" --target "$LIBS" -r "$REQ"; then
  echo ""
  echo "[offline] ERRORE durante l'installazione."
  echo "          Verifica che la versione di Python sia 3.12 (Ubuntu 24):"
  echo "          le wheel binarie (pydantic-core, uvloop) sono compilate per cp312."
  exit 1
fi

echo "[offline] verifica import ..."
MODS="fastapi uvicorn pymodbus starlette pydantic_core websockets"
[[ "$REQ" == *attacker* ]] && MODS="$MODS scapy"
if PYTHONPATH="$LIBS" python3 -c "
import importlib, sys
mods='$MODS'.split()
for m in mods:
    importlib.import_module(m)
print('[offline] OK: ' + ', '.join(mods))
"; then
  echo "[offline] completato. I launcher useranno automaticamente vendor/libs."
else
  echo "[offline] le librerie non si importano: Python non e' 3.12? ($(python3 --version 2>&1))"
  exit 1
fi
