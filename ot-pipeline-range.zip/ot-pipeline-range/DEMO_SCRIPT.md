# OT Pipeline Range — Script della dimostrazione (Red vs Blue)

Furto fisico di cherosene a un terminale, nascosto a Centro con un **MITM Modbus/TCP reale**.
Durata: **6–8 minuti**.

## Prerequisiti
- `topology.conf` con gli IP reali su tutte le macchine.
- 6 macchine sulla stessa L2.
- Avviate nell'ordine: **siti → Centro → Kali**.
  - su ogni Ubuntu di sito: `./run-militaryairport1.sh` (o `run-pumping/distribution/militaryairport2`)
  - su Centro: `./run-centralhmi.sh`
  - su Kali: `./run-attacker.sh`

Proietta affiancate la **SCADA di Centro** e la **console Red Team** (Kali).

---

## Atto 1 — Esercizio normale (≈1 min)
- **Centro**: bilancio **VERDE**, `Mandata Pumping ≈ Ricezione (Military Airport 1+Military Airport 2)`, ~0% sbilanciamento.
- **HMI Military Airport 1** (sul suo box): portata nominale ~450 m³/h, serbatoi in salita.
- *"Tutto nominale: il campo e il centro sono d'accordo."*

## Atto 2 — Furto fisico (≈1.5 min)  — passo ① sulla console Kali
1. Bersaglio: **Military Airport 1**. Spillamento: **60 m³/h**.
2. Premi **Apri spillamento (PLC)**.

Cosa mostrare:
- **HMI Military Airport 1**: la portata **reale** scende (~390 m³/h) — il PLC vede il calo vero.
- **Centro**: la ricezione cala → **banner rosso lampeggiante "ALLARME AMMANCO"**, il nodo
  del terminale lampeggia, bilancio ~7% (soglia ±2%). È il momento scenico: l'operatore
  "vede" il furto.
- Console: verdetto rosso **"ALLARME A CENTRAL — decezione fallita"**.
- *"Senza occultamento, un banale controllo di bilancio di massa becca subito il furto."*

## Atto 3 — Il tampering che nasconde tutto (≈2 min) — a mano dalla Kali
Il MITM è un'azione reale dell'attaccante: si esegue dal terminale (vedi
`PLAYBOOK_MANUALE.md`), non da un bottone. In breve, sull'attacker:
```bash
# versione base (offset): puoi lanciarla a spillamento già aperto
sudo bash attacker/run_mitm.sh start $CENTRAL $MILITARYAIRPORT1 60 offset
# versione stealth: lancia PRIMA, ~8s di apprendimento, POI apri lo spillamento
sudo bash attacker/run_mitm.sh start $CENTRAL $MILITARYAIRPORT1 60 consistent
```
Parte l'ARP spoofing tra la workstation Military Airport 1 e Centro; il tcp/502 viene dirottato
nel proxy che riscrive i registri nelle risposte verso Centro. Sulla console compare
**MASCHERAMENTO: SÌ** (rilevato dal confronto reale vs Centro).

Osserva:
   - **Centro torna VERDE**: il banner rosso sparisce, i nodi smettono di lampeggiare,
     ricezione Military Airport 1 di nuovo ~450, bilancio rientrato. È evidente che qualcuno ha
     "spento" l'allarme mascherando i dati.
   - **HMI Military Airport 1** (box di sito): continua a mostrare ~390 — **il campo non mente**.
   - Console: box REALE ~390 vs vista Centro ~450; verdetto verde **"furto invisibile"**;
     contatore **cherosene esfiltrato** che sale (~1000 L/min).
- *"Stesso furto di prima, ma ora Centro vede il nominale. Il MITM riallinea il bilancio."*

> Prova del nove on-wire: nei log della Kali il proxy stampa `risposte falsificate` con
> il valore riscritto (reg0 vero → reg0 falso).

## Atto 4 — Scoperta e danno (≈1 min)
- Mostra la **divergenza** HMI Military Airport 1 (reale) vs Centro (falso): è questa l'anomalia.
- Alza lo spillamento o sposta il bersaglio su **Military Airport 2**: la tecnica scala.
- Supply chain: prodotto militare sottratto, ammanco invisibile al centro in tempo reale.

## Atto 5 — Chiusura Blue (≈1 min)
- **Ferma il MITM** (`sudo bash attacker/run_mitm.sh stop`, o Ctrl-C sui processi a mano)
  → Centro torna subito ROSSO: la difesa più semplice è non fidarsi del singolo canale.
- Rilevamento da citare:
  - **cross-check locale vs centrale** (HMI di sito confrontata con Centro): il MITM non
    tocca il dato locale, quindi la divergenza lo smaschera — **resta valido anche contro
    Coerente e Replay**, che battono invece il solo bilancio a Centro;
  - **anti-ARP-spoofing** (DAI/arpwatch), **monitoraggio OT passivo (NDR)** sui pattern Modbus;
  - **integrità/attestazione** dei messaggi RTU (firma/sequenze): fa fallire anche il replay.

> Nota didattica: mostra prima **Offset** e fai notare che il livello serbatoio a Centro
> non torna (smascherabile), poi passa a **Coerente/Replay** per far vedere come un
> attaccante più accurato chiude anche quel buco. È il cuore del messaggio Red vs Blue.

---

### Reset tra le prove
Console → chiudi spillamento e ferma MITM, oppure su ogni macchina `./run-stop.sh`
(ripristina ARP e iptables) e riavvia.

### Valori di riferimento
| Grandezza | Nominale |
|---|---|
| Mandata Pumping | ~800 m³/h |
| Ricezione Military Airport 1 / Military Airport 2 | 450 / 350 m³/h |
| Soglia allarme ammanco | ±2.0 % |
| Spillamento demo | 60 m³/h ≈ 1000 L/min |
