#!/usr/bin/env bash
# Lanciatore per centralhmi — installa (al primo avvio) e avvia il ruolo.
exec "$(cd "$(dirname "$0")" && pwd)/scripts/launch.sh" central
