// OTR Demo - engine condiviso (client WS + helper di rendering)

// --- risoluzione host backend -------------------------------------------
// Le pagine vittima (central/site) usano lo stesso origin del backend.
// La console attaccante (Kali) punta a un host remoto: ?host=IP oppure campo salvato.
function resolveBase() {
  const q = new URLSearchParams(location.search);
  let host = q.get("host") || localStorage.getItem("otr_host") || "";
  if (host) {
    if (host.includes("://")) host = host.split("://")[1];
    return { http: `http://${host}`, ws: `ws://${host}` };
  }
  // same-origin
  const wsproto = location.protocol === "https:" ? "wss:" : "ws:";
  return { http: location.origin, ws: `${wsproto}//${location.host}` };
}

window.OTR = {
  base: resolveBase(),
  listeners: [],
  last: null,

  onState(fn){ this.listeners.push(fn); },

  connect(){
    const url = this.base.ws + "/ws";
    const setPill = (ok) => {
      const p = document.getElementById("conn");
      if(!p) return;
      p.className = "pill " + (ok ? "ok":"bad");
      p.querySelector(".txt").textContent = ok ? "LINK OT ATTIVO" : "LINK OT ASSENTE";
    };
    const open = () => {
      const ws = new WebSocket(url);
      ws.onopen = () => setPill(true);
      ws.onclose = () => { setPill(false); setTimeout(open, 1500); };
      ws.onerror = () => { try{ws.close();}catch(e){} };
      ws.onmessage = (ev) => {
        const s = JSON.parse(ev.data);
        this.last = s;
        this.listeners.forEach(fn => { try{ fn(s); }catch(e){ console.error(e);} });
      };
      this._ws = ws;
    };
    open();
  },

  async sendAttack(patch){
    try{
      const r = await fetch(this.base.http + "/api/attack", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify(patch)
      });
      return await r.json();
    }catch(e){ console.error("attack cmd failed", e); return null; }
  },
};

// --- helper di formato ---------------------------------------------------
function fmt(n, d=0){ return Number(n).toLocaleString("it-IT",{minimumFractionDigits:d,maximumFractionDigits:d}); }

// --- orologio topbar -----------------------------------------------------
function startClock(){
  const el = document.getElementById("clock");
  if(!el) return;
  const t = () => { el.textContent = new Date().toLocaleString("it-IT",{hour12:false}); };
  t(); setInterval(t, 1000);
}

// --- gauge semicircolare -------------------------------------------------
function drawGauge(el, value, min, max, unit, color){
  const pct = Math.max(0, Math.min(1, (value-min)/(max-min)));
  const a = Math.PI * (1 - pct); // da sinistra (PI) a destra (0)
  const cx=75, cy=82, r=62;
  const x = cx + r*Math.cos(a), y = cy - r*Math.sin(a);
  const large = 0; const sweepBg = `M13,82 A62,62 0 0 1 137,82`;
  const sweepFg = `M13,82 A62,62 0 0 1 ${x.toFixed(1)},${y.toFixed(1)}`;
  el.innerHTML = `
    <svg viewBox="0 0 150 92">
      <path d="${sweepBg}" fill="none" stroke="#1c2a39" stroke-width="12" stroke-linecap="round"/>
      <path d="${sweepFg}" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round"/>
    </svg>
    <div class="gv" style="color:${color}">${fmt(value, unit==="bar"?1:0)}</div>
    <div class="gl">${unit}</div>`;
}

// --- serbatoio -----------------------------------------------------------
function drawTank(el, pct, color){
  el.innerHTML = `
    <div class="fluid" style="height:${Math.max(2,Math.min(100,pct))}%;background:linear-gradient(180deg,${color},#0d2f52)">
      <div class="wave"></div>
    </div>
    <div class="pct">${fmt(pct,1)}%</div>`;
}
