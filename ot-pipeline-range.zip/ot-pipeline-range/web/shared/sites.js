// OTR Demo - configurazione siti (rispecchia sim.py)
window.OTR_SITES = {
  pumping:  { name:"Pumping",  subtitle:"Stazione di pompaggio",     role:"sorgente",   accent:"#2e86de", nominal_flow:800, nominal_pressure:52, tanks:4 },
  distribution:{ name:"Distribution", subtitle:"Nodo di distribuzione",     role:"nodo",       accent:"#e1a33a", nominal_flow:800, nominal_pressure:46, tanks:2 },
  militaryairport1:     { name:"Military Airport 1",      subtitle:"Terminale aeroportuale", role:"terminale",  accent:"#8e44ad", nominal_flow:450, nominal_pressure:38, tanks:3 },
  militaryairport2:    { name:"Military Airport 2",     subtitle:"Terminale aeroportuale", role:"terminale",  accent:"#27a567", nominal_flow:350, nominal_pressure:36, tanks:3 },
};
window.OTR_ORDER = ["pumping","distribution","militaryairport1","militaryairport2"];
window.OTR_THEFT_TARGETS = ["militaryairport1","militaryairport2"];
