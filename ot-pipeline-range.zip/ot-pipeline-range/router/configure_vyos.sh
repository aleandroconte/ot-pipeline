#!/bin/vbash
# =====================================================================
#  OTR cyber range — configurazione router VyOS 1.5 LTS
#  Collega le due subnet del teatro e instrada tra loro.
#
#  Mappatura NIC (VERIFICA sul tuo teatro con 'show interfaces' e correggi):
#    eth0 -> subnet FIELD  (4 siti + attacker)   10.10.10.0/24  gw .150
#    eth1 -> subnet CENTER (centralhmi)           10.10.50.0/24  gw .150
#
#  Uso sul router:
#    vyos@vyos:~$  bash /config/scripts/configure_vyos.sh
#  (oppure copia/incolla i 'set' di router/vyos-router-1.5.conf in 'configure')
# =====================================================================

# assicura il gruppo di configurazione corretto
if [ "$(id -g -n)" != 'vyattacfg' ] ; then
    exec sg vyattacfg -c "/bin/vbash $(readlink -f "$0") $*"
fi
source /opt/vyatta/etc/functions/script-template

configure

# --- identità ---
set system host-name 'router'

# --- interfaccia subnet FIELD (siti + attacker) ---
set interfaces ethernet eth0 address '10.10.10.150/24'
set interfaces ethernet eth0 description 'field'

# --- interfaccia subnet CENTER (centralhmi) ---
set interfaces ethernet eth1 address '10.10.50.150/24'
set interfaces ethernet eth1 description 'center'

# --- gestione SSH ---
set service ssh port '22'

# --- firewall: LAB PERMISSIVO ---
# Instrada TUTTO tra le due subnet. L'ARP spoofing della Kali è L2 e resta
# dentro la subnet campo: il router non lo vede né lo blocca.
set firewall ipv4 forward filter default-action 'accept'
set firewall ipv4 input   filter default-action 'accept'

# --- (OPZIONALE) uscita internet per il primo avvio degli host ---
# Scommenta se il teatro NON fornisce già internet/proxy agli host e vuoi
# che sia il router a darlo. eth2 = WAN in DHCP, NAT masquerade.
# set interfaces ethernet eth2 address 'dhcp'
# set interfaces ethernet eth2 description 'wan-internet'
# set nat source rule 100 outbound-interface name 'eth2'
# set nat source rule 100 source address '10.10.0.0/16'
# set nat source rule 100 translation address 'masquerade'
# set system name-server '1.1.1.1'

commit
save
exit
echo "[router] configurazione applicata e salvata."
