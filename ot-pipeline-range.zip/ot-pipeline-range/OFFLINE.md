# Installazione OFFLINE (niente rete, proxy, snap)

Questo bundle contiene **già tutte le librerie Python** in `vendor/wheels/`
(fastapi, uvicorn, pymodbus, scapy e dipendenze). Non serve `pip install`,
non serve il proxy, non serve lo snap store. Serve solo `python3`, che su
Ubuntu 24 è già installato.

> Le wheel binarie (pydantic-core, uvloop, httptools, websockets) sono
> compilate per **Python 3.12** (quello di Ubuntu 24.04). Verifica con
> `python3 --version`: deve essere 3.12.x.

## Uso normale — non devi fare nulla di speciale

Lancia il ruolo della macchina come al solito:

```bash
./run-pumping.sh            # oppure distribution / militaryairport1 / militaryairport2
./run-centralhmi.sh        # sulla centralhmi
./run-attacker.sh          # sulla Kali
```

Al **primo avvio** il launcher trova `vendor/wheels/`, installa da lì in
`vendor/libs/` (zero rete) e parte. Dalle volte successive usa direttamente
`vendor/libs/`. La GUI si apre nel browser presente (Firefox va benissimo);
se non si apre da sola, vai su `http://localhost:8080/`.

## Installazione manuale (se preferisci farla prima a mano)

```bash
./install_offline.sh            # siti e centralhmi
./install_offline.sh attacker   # solo sulla Kali (aggiunge scapy)
```

Deve finire con `[offline] OK: fastapi, uvicorn, pymodbus, ...`.

## Come funziona (così sai dove guardare se qualcosa non va)

- `vendor/wheels/` → le librerie `.whl` scaricate una volta sola.
- `install_offline.sh` → fa partire `pip` dalla sua wheel (senza pip nel
  sistema) e installa tutto in `vendor/libs/` con `--no-index` (nessuna rete).
- `scripts/launch.sh` → usa `vendor/libs/` via `PYTHONPATH`. Ordine di
  priorità: `.venv` → `vendor/libs` → install offline → (ultima spiaggia)
  install online con proxy.

Se vedi `le librerie non si importano: Python non è 3.12`, la macchina ha una
versione diversa di Python: dimmelo e ti rigenero le wheel per quella.

## Se proprio vuoi la via online (sconsigliata dietro proxy)

```bash
export http_proxy=http://10.89.254.254:3128 https_proxy=http://10.89.254.254:3128
rm -rf vendor/libs vendor/wheels    # forza il percorso online
./run-pumping.sh
```
