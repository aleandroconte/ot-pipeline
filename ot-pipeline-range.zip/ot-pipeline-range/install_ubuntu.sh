#!/usr/bin/env bash
# Installazione dipendenze su Ubuntu 24 (box di SITO o CENTRAL).
# Idempotente: la richiama da sola ./run-<macchina>.sh al primo avvio.
# Dietro proxy: esporta http_proxy/https_proxy prima di lanciare (apt usa sudo -E).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive

# NB: percorso ONLINE di riserva. Quello consigliato e' ./install_offline.sh
# (usa vendor/wheels, niente rete). Niente chromium: su Ubuntu 24 e' uno snap
# che dietro proxy si blocca sullo store; la GUI si apre col browser presente.
echo "[setup] apt: python3-venv, python3-pip"
sudo -E apt-get update -y
sudo -E apt-get install -y python3-venv python3-pip

echo "[setup] virtualenv + pip"
python3 -m venv "$ROOT/.venv"
"$ROOT/.venv/bin/pip" install --upgrade pip >/dev/null
"$ROOT/.venv/bin/pip" install -r "$ROOT/requirements.txt"

chmod +x "$ROOT"/run-*.sh "$ROOT"/scripts/*.sh 2>/dev/null || true
[[ -f "$ROOT/topology.conf" ]] || cp "$ROOT/topology.conf.example" "$ROOT/topology.conf"
echo "[setup] completato."
